import { useState, useRef, useEffect } from "react";

// ─── PROMPTS ──────────────────────────────────────────────────────────────────

const SYSTEM_CHAT = `Tu es Maître Hassan, expert-comptable et fiscaliste marocain avec 25 ans d'expérience, inscrit à l'Ordre des Experts-Comptables du Maroc (OECM).

STRUCTURE DE RÉPONSE OBLIGATOIRE — toujours en 4 parties :

## 📖 Ce que dit le CGI
Cite l'article exact : "Art. 19-I-B – CGI 2024", reformule clairement la règle de droit.

## 🔍 Doctrine & Circulaires DGI
Mentionne les notes circulaires DGI pertinentes, positions officielles, jurisprudence fiscale marocaine.

## 💼 Expérience terrain
Ce que tu as vu dans ta pratique : erreurs fréquentes, points de contrôle lors des vérifications fiscales DGI, astuces d'optimisation légale, pièges à éviter.

## 🧮 Exemple chiffré concret
Simulation avec montants réels en DH. Utilise des tableaux | colonnes |. Écritures PCM si pertinent.

**Mon avis professionnel :** termine par ta recommandation personnelle.

RÈGLES : cite toujours l'article CGI exact · signale les nouveautés LF 2024 · sois direct et pratique · utilise des tableaux pour les barèmes · réponds en français (ou arabe si question en arabe).`;

const SYSTEM_CAS = `Tu es Maître Hassan, expert-comptable et fiscaliste marocain avec 25 ans d'expérience.
Analyse ce cas pratique et réponds UNIQUEMENT avec ce JSON valide, sans aucun texte avant ou après :
{"titre":"string","resume":"string","analyse_comptable":{"sections":[{"sous_titre":"string","contenu":"string","ecritures":[{"compte":"6123","libelle":"string","debit":0,"credit":0}],"references_pcm":["string"]}]},"analyse_fiscale":{"sections":[{"sous_titre":"string","contenu":"string","articles_cgi":["string"],"calculs":[{"libelle":"string","montant":0,"taux":0.20,"resultat":0}]}]},"synthese":{"points_cles":["string"],"risques":["string"],"recommandations":["string"]},"avis_expert":"string","articles_cites":["string"]}`;

const SUGGESTIONS_CHAT = [
  "Taux IS SARL 2024 et cotisation minimale ?",
  "Taux TVA par catégorie de produits au Maroc ?",
  "Barème IR salariés 2024 — tranches et abattements ?",
  "Retenue à la source sur honoraires versés à un tiers ?",
  "Délais de déclaration IS, TVA, IR en 2024 ?",
  "Charges déductibles IS — conditions et limites CGI ?",
  "Dividendes distribués : retenue à la source applicable ?",
  "Amortissements — taux fiscaux admis par la DGI ?",
];

const SUGGESTIONS_CAS = [
  "SARL avec CA 2 500 000 DH, bénéfice 480 000 DH. Calculer IS et CM.",
  "Achat véhicule tourisme 350 000 DH TTC. Écritures et TVA récupérable.",
  "Provision pour créances douteuses 120 000 DH. Déductibilité IS ?",
  "Gérant associé : rémunération 25 000 DH/mois. Retenue source et déductibilité.",
  "Dividendes distribués 300 000 DH à actionnaire personne physique.",
  "Importation marchandises 500 000 DH. TVA importation et droits de douane.",
];

// ─── UTILS ────────────────────────────────────────────────────────────────────

function fmtDH(n) {
  if (n == null) return "–";
  return Number(n).toLocaleString("fr-MA") + " DH";
}

// Génère le HTML d'impression pour une réponse chat
function buildChatHTML(question, answer, title) {
  const md2html = (t) => (t || "")
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/## (.*)/g, "<h3 style='color:#1a4a1a;margin:14px 0 6px'>$1</h3>")
    .replace(/^- (.+)/gm, "<li>$1</li>")
    .replace(/\n/g, "<br>");
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${title}</title>
  <style>
    body{font-family:Georgia,serif;max-width:800px;margin:32px auto;color:#111;padding:0 24px;font-size:14px}
    .header{border-bottom:3px solid #c9a84c;padding-bottom:12px;margin-bottom:24px}
    .header h1{color:#1a4a1a;margin:0 0 4px;font-size:1.4em}
    .header p{color:#666;margin:0;font-size:.82em}
    .question{background:#f0f7f0;border-left:4px solid #2d5a2d;padding:12px 16px;border-radius:0 8px 8px 0;margin-bottom:20px}
    .question .label{font-size:.72em;font-weight:bold;color:#2d5a2d;text-transform:uppercase;margin-bottom:6px}
    .answer{background:#fdf8ee;border-left:4px solid #c9a84c;padding:14px 18px;border-radius:0 8px 8px 0}
    .answer .label{font-size:.72em;font-weight:bold;color:#8a6a1a;text-transform:uppercase;margin-bottom:8px}
    table{border-collapse:collapse;width:100%;margin:10px 0;font-size:.88em}
    th{background:#1a4a1a;color:#fff;padding:6px 10px;text-align:left}
    td{padding:6px 10px;border-bottom:1px solid #ddd}
    tr:nth-child(even){background:#f9f9f0}
    .footer{margin-top:32px;border-top:1px solid #ccc;padding-top:8px;font-size:.7em;color:#888;text-align:center}
    li{margin:4px 0}
  </style></head><body>
  <div class="header">
    <h1>⚖️ Consultation CGI Maroc — Maître Hassan</h1>
    <p>Expert-Comptable · OECM · CGI 2024 &nbsp;|&nbsp; ${new Date().toLocaleDateString("fr-FR", { dateStyle: "long" })}</p>
  </div>
  <div class="question"><div class="label">👤 Question posée</div>${question}</div>
  <div class="answer"><div class="label">⚖️ Réponse — Maître Hassan</div>${md2html(answer)}</div>
  <div class="footer">fiscalite-maroc.ma · CGI Maroc 2024 · IS · TVA · IR · Plan Comptable Marocain</div>
  </body></html>`;
}

// Génère le HTML d'impression pour un cas pratique
function buildCasHTML(question, data) {
  if (!data) return buildChatHTML(question, "Analyse non disponible", "Cas Pratique");
  const ecrituresHtml = (ecritures) => {
    if (!ecritures?.length) return "";
    const rows = ecritures.map((e, i) => `
      <tr style="background:${i % 2 === 0 ? "#f9f9f0" : "#fff"}">
        <td style="font-family:monospace;color:#2d5a2d">${e.compte}</td>
        <td>${e.libelle}</td>
        <td style="text-align:right">${e.debit > 0 ? fmtDH(e.debit) : "–"}</td>
        <td style="text-align:right">${e.credit > 0 ? fmtDH(e.credit) : "–"}</td>
      </tr>`).join("");
    const td = ecritures.reduce((s, e) => s + (e.debit || 0), 0);
    const tc = ecritures.reduce((s, e) => s + (e.credit || 0), 0);
    return `<table><thead><tr><th>Compte</th><th>Libellé</th><th style="text-align:right">Débit (DH)</th><th style="text-align:right">Crédit (DH)</th></tr></thead>
    <tbody>${rows}<tr style="background:#1a4a1a;color:#fff;font-weight:bold">
      <td colspan="2">TOTAUX</td><td style="text-align:right">${fmtDH(td)}</td><td style="text-align:right">${fmtDH(tc)}</td>
    </tr></tbody></table>`;
  };
  const calculsHtml = (calculs) => {
    if (!calculs?.length) return "";
    return `<table><thead><tr><th>Libellé</th><th>Montant</th><th>Taux</th><th>Résultat</th></tr></thead><tbody>
      ${calculs.map((c, i) => `<tr style="background:${i % 2 === 0 ? "#f9f9f0" : "#fff"}">
        <td>${c.libelle}</td><td>${c.montant != null ? fmtDH(c.montant) : "–"}</td>
        <td>${c.taux != null ? (c.taux * 100).toFixed(0) + "%" : "–"}</td>
        <td style="font-weight:bold;color:#1a4a1a">${c.resultat != null ? fmtDH(c.resultat) : "–"}</td>
      </tr>`).join("")}
    </tbody></table>`;
  };
  const listHtml = (items, color) => (items || []).map(x => `<li style="color:${color};margin:5px 0">${x}</li>`).join("");

  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Cas Pratique — ${data.titre}</title>
  <style>
    body{font-family:Georgia,serif;max-width:820px;margin:32px auto;color:#111;padding:0 24px;font-size:14px}
    .header{border-bottom:3px solid #c9a84c;padding-bottom:12px;margin-bottom:20px}
    .header h1{color:#1a4a1a;margin:0 0 4px;font-size:1.35em}
    .header p{color:#666;margin:0;font-size:.82em}
    .resume{background:#fdf8ee;border-left:4px solid #c9a84c;padding:12px 16px;border-radius:0 8px 8px 0;margin-bottom:18px;font-style:italic;color:#555}
    .section{margin-bottom:22px;page-break-inside:avoid}
    .section h2{color:#1a4a1a;font-size:1.05em;border-bottom:2px solid #c9a84c;padding-bottom:5px;margin-bottom:10px}
    .section h3{color:#2d5a2d;font-size:.95em;margin:12px 0 6px}
    .section p{color:#333;line-height:1.7;margin:6px 0}
    table{border-collapse:collapse;width:100%;margin:10px 0;font-size:.87em}
    th{background:#1a4a1a;color:#fff;padding:6px 10px;text-align:left}
    td{padding:6px 10px;border-bottom:1px solid #ddd}
    .badge{display:inline-block;background:#fdf0d0;border:1px solid #c9a84c;border-radius:20px;padding:2px 10px;font-size:.78em;color:#8a6a1a;margin:2px}
    .synthese-box{border-radius:8px;padding:12px 16px;margin-bottom:12px}
    .pts{background:#f0f7f0;border-left:3px solid #2d5a2d}
    .risques{background:#fffbf0;border-left:3px solid #c9a84c}
    .reco{background:#f0f4ff;border-left:3px solid #4a6aaa}
    .avis{background:#fdf8ee;border:1px solid #c9a84c;border-radius:8px;padding:14px 16px;font-style:italic;color:#555;margin-top:14px}
    .avis strong{color:#1a4a1a;font-style:normal}
    .footer{margin-top:32px;border-top:1px solid #ccc;padding-top:8px;font-size:.7em;color:#888;text-align:center}
    li{margin:4px 0}
  </style></head><body>
  <div class="header">
    <h1>📋 Cas Pratique — ${data.titre}</h1>
    <p>Maître Hassan · Expert-Comptable OECM · CGI 2024 &nbsp;|&nbsp; ${new Date().toLocaleDateString("fr-FR", { dateStyle: "long" })}</p>
  </div>
  <div class="resume">${data.resume}</div>
  <div style="margin-bottom:16px">${(data.articles_cites || []).map(a => `<span class="badge">📌 ${a}</span>`).join("")}</div>

  <div class="section"><h2>📒 Analyse Comptable</h2>
    ${(data.analyse_comptable?.sections || []).map(s => `
      <h3>▸ ${s.sous_titre}</h3>
      <p>${s.contenu}</p>
      ${ecrituresHtml(s.ecritures)}
      ${(s.references_pcm || []).map(r => `<span class="badge">📗 ${r}</span>`).join("")}
    `).join("")}
  </div>

  <div class="section"><h2>⚖️ Analyse Fiscale</h2>
    ${(data.analyse_fiscale?.sections || []).map(s => `
      <h3>▸ ${s.sous_titre}</h3>
      <p>${s.contenu}</p>
      ${calculsHtml(s.calculs)}
      ${(s.articles_cgi || []).map(a => `<span class="badge">📌 ${a}</span>`).join("")}
    `).join("")}
  </div>

  <div class="section"><h2>🎯 Synthèse</h2>
    <div class="synthese-box pts"><strong style="color:#2d5a2d">✅ Points Clés</strong><ul>${listHtml(data.synthese?.points_cles, "#333")}</ul></div>
    <div class="synthese-box risques"><strong style="color:#8a6a1a">⚠️ Risques Fiscaux</strong><ul>${listHtml(data.synthese?.risques, "#333")}</ul></div>
    <div class="synthese-box reco"><strong style="color:#2a4a8a">💡 Recommandations</strong><ul>${listHtml(data.synthese?.recommandations, "#333")}</ul></div>
    ${data.avis_expert ? `<div class="avis"><strong>🎓 Avis de Maître Hassan :</strong><br>"${data.avis_expert}"</div>` : ""}
  </div>

  <div class="footer">fiscalite-maroc.ma · CGI Maroc 2024 · IS · TVA · IR · Plan Comptable Marocain</div>
  </body></html>`;
}

function openPrint(html, filename) {
  try {
    // Méthode 1 : téléchargement direct du fichier HTML
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = (filename || "consultation-cgi-maroc") + ".html";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  } catch (err) {
    // Méthode 2 : data URI fallback
    try {
      const encoded = "data:text/html;charset=utf-8," + encodeURIComponent(html);
      const a = document.createElement("a");
      a.href = encoded;
      a.download = (filename || "consultation-cgi-maroc") + ".html";
      a.click();
    } catch (_) {
      alert("Export non disponible dans cet environnement. Copiez le texte avec le bouton 📋");
    }
  }
}

function copyText(text, setCopied) {
  navigator.clipboard.writeText(text).then(() => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  });
}

// ─── MARKDOWN ─────────────────────────────────────────────────────────────────

function MD({ text }) {
  if (!text) return null;
  const lines = text.split("\n");
  const out = [];
  let tableRows = [];

  const flushTable = () => {
    if (!tableRows.length) return;
    out.push(
      <div key={`t${out.length}`} style={{ overflowX: "auto", margin: "10px 0" }}>
        <table style={{ borderCollapse: "collapse", fontSize: "0.84em", width: "100%" }}>
          <tbody>
            {tableRows.map((row, ri) => (
              <tr key={ri} style={{ background: ri === 0 ? "#1a2e1a" : ri % 2 === 0 ? "#0f1a0f" : "#0d160d", borderBottom: "1px solid #2a3d2a" }}>
                {row.map((cell, ci) => (
                  <td key={ci} style={{ padding: "6px 12px", color: ri === 0 ? "#7ec880" : "#c8c0a8", fontWeight: ri === 0 ? "bold" : "normal" }}
                    dangerouslySetInnerHTML={{ __html: cell }} />
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
    tableRows = [];
  };

  lines.forEach((line, i) => {
    const h = line
      .replace(/\*\*(.*?)\*\*/g, '<strong style="color:#e8d4a0">$1</strong>')
      .replace(/\*(.*?)\*/g, "<em>$1</em>")
      .replace(/`(.*?)`/g, '<code style="background:#1a2a1a;padding:1px 5px;border-radius:3px;color:#7ec880;font-size:.88em">$1</code>');

    if (line.startsWith("|")) {
      const cells = line.split("|").filter(Boolean).map((c) => c.trim());
      if (cells.every((c) => /^[-:]+$/.test(c))) return;
      tableRows.push(cells.map((c) => c.replace(/\*\*(.*?)\*\*/g, '<strong style="color:#e8d4a0">$1</strong>')));
      return;
    }
    flushTable();
    if (line.startsWith("# "))   { out.push(<h3 key={i} style={{ color:"#c9a84c",margin:"16px 0 8px",fontSize:"1.1em" }} dangerouslySetInnerHTML={{ __html:h.slice(2) }} />); return; }
    if (line.startsWith("## "))  { out.push(<h4 key={i} style={{ color:"#a8c5a8",margin:"14px 0 6px",fontSize:"1em",borderBottom:"1px solid #2a3d2a",paddingBottom:4 }} dangerouslySetInnerHTML={{ __html:h.slice(3) }} />); return; }
    if (line.startsWith("### ")) { out.push(<h5 key={i} style={{ color:"#8ab8a8",margin:"10px 0 4px",fontSize:"0.95em" }} dangerouslySetInnerHTML={{ __html:h.slice(4) }} />); return; }
    if (line.startsWith("- ") || line.startsWith("• ")) {
      out.push(<div key={i} style={{ display:"flex",gap:8,marginBottom:4 }}><span style={{ color:"#c9a84c",flexShrink:0 }}>◆</span><span style={{ color:"#ddd0b8" }} dangerouslySetInnerHTML={{ __html:h.slice(2) }} /></div>);
      return;
    }
    if (/^\d+\./.test(line)) { out.push(<div key={i} style={{ marginBottom:4,color:"#ddd0b8" }} dangerouslySetInnerHTML={{ __html:h }} />); return; }
    if (line === "") { out.push(<div key={i} style={{ height:6 }} />); return; }
    out.push(<p key={i} style={{ margin:"0 0 5px",color:"#ddd0b8",lineHeight:1.75 }} dangerouslySetInnerHTML={{ __html:h }} />);
  });
  flushTable();
  return <div style={{ fontSize:"0.875em" }}>{out}</div>;
}

// ─── ACTION BAR ───────────────────────────────────────────────────────────────

function ActionBar({ onExport, plainText }) {
  const [copied, setCopied] = useState(false);
  const [exported, setExported] = useState(false);
  const [shared, setShared] = useState(false);

  const handleExport = () => {
    onExport();
    setExported(true);
    setTimeout(() => setExported(false), 3000);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(plainText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (_) {
      // fallback
      const ta = document.createElement("textarea");
      ta.value = plainText;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({ title: "Consultation CGI Maroc — Maître Hassan", text: plainText.slice(0, 400) });
      } else {
        await handleCopy();
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      }
    } catch (_) { handleCopy(); }
  };

  const btn = (onClick, icon, label, active) => (
    <button onClick={onClick} style={{
      background: active ? "#1a3a1a" : "#0f1a0f",
      border: `1px solid ${active ? "#3a7a3a" : "#2a3d2a"}`,
      borderRadius: 8, padding: "5px 12px",
      color: active ? "#7ec880" : "#5a7a5a",
      cursor: "pointer", fontSize: "0.73em", fontFamily: "inherit",
      display: "flex", alignItems: "center", gap: 5, transition: "all .15s"
    }}
      onMouseEnter={(e) => { if (!active) { e.currentTarget.style.borderColor = "#c9a84c"; e.currentTarget.style.color = "#c9a84c"; }}}
      onMouseLeave={(e) => { if (!active) { e.currentTarget.style.borderColor = "#2a3d2a"; e.currentTarget.style.color = "#5a7a5a"; }}}>
      {icon} {label}
    </button>
  );

  return (
    <div style={{ display: "flex", gap: 6, marginTop: 10, paddingTop: 8, borderTop: "1px solid #1a2a1a", flexWrap: "wrap", alignItems: "center" }}>
      {btn(handleExport, "📥", exported ? "✅ Téléchargé !" : "Télécharger HTML", exported)}
      {btn(handleCopy,   "📋", copied   ? "✅ Copié !"      : "Copier texte",     copied)}
      {btn(handleShare,  "🔗", shared   ? "✅ Partagé !"    : "Partager",         shared)}
      {exported && <span style={{ fontSize: "0.7em", color: "#5a7a5a", fontStyle: "italic" }}>Ouvrez le fichier téléchargé pour imprimer en PDF</span>}
    </div>
  );
}

// ─── CAS PRATIQUE VIEW ────────────────────────────────────────────────────────

function CasView({ data, question, onExport }) {
  const [tab, setTab] = useState("comptable");

  const TB = (id, icon, label) => (
    <button onClick={() => setTab(id)} style={{ background: tab === id ? "#1a1408" : "transparent", border: "none", borderBottom: `2px solid ${tab === id ? "#c9a84c" : "transparent"}`, borderRadius: "8px 8px 0 0", padding: "8px 16px", color: tab === id ? "#c9a84c" : "#4a6a4a", cursor: "pointer", fontSize: "0.82em", fontFamily: "inherit" }}>
      {icon} {label}
    </button>
  );

  return (
    <div style={{ fontSize: "0.85em" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#1a1a0a,#2a1e08)", border: "1px solid #c9a84c44", borderRadius: 10, padding: "12px 16px", marginBottom: 12 }}>
        <div style={{ color: "#c9a84c", fontWeight: "bold", fontSize: "1.05em", marginBottom: 4 }}>📋 {data.titre}</div>
        <div style={{ color: "#aaa090", lineHeight: 1.6, marginBottom: 8 }}>{data.resume}</div>
        {data.articles_cites?.length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
            {data.articles_cites.map((a, i) => <span key={i} style={{ background: "#2a1e08", border: "1px solid #c9a84c44", borderRadius: 20, padding: "2px 10px", fontSize: "0.76em", color: "#c9a84c" }}>📌 {a}</span>)}
          </div>
        )}
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", borderBottom: "1px solid #2a2208", marginBottom: 12 }}>
        {TB("comptable", "📒", "Comptable")}
        {TB("fiscale",   "⚖️", "Fiscale")}
        {TB("synthese",  "🎯", "Synthèse")}
      </div>

      {/* ── COMPTABLE ── */}
      {tab === "comptable" && (data.analyse_comptable?.sections || []).map((s, i) => (
        <div key={i} style={{ background: "#141208", border: "1px solid #2a2208", borderRadius: 10, padding: "14px 16px", marginBottom: 10 }}>
          <div style={{ color: "#7ec880", fontWeight: "bold", marginBottom: 8 }}>▸ {s.sous_titre}</div>
          <div style={{ color: "#c8c0a8", lineHeight: 1.75, marginBottom: s.ecritures?.length ? 14 : 0 }}>{s.contenu}</div>
          {s.ecritures?.length > 0 && (
            <>
              <div style={{ fontSize: "0.7em", color: "#5a7a5a", letterSpacing: "0.05em", marginBottom: 6 }}>ÉCRITURES PCM</div>
              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.82em" }}>
                  <thead><tr style={{ background: "#1a2e1a" }}>
                    {["N° Compte", "Libellé", "Débit (DH)", "Crédit (DH)"].map((h) => (
                      <th key={h} style={{ padding: "7px 10px", textAlign: h.includes("bit") || h.includes("dit") ? "right" : "left", color: "#7ec880", borderBottom: "1px solid #2a3d2a", fontWeight: 600, whiteSpace: "nowrap" }}>{h}</th>
                    ))}
                  </tr></thead>
                  <tbody>
                    {s.ecritures.map((e, j) => (
                      <tr key={j} style={{ borderBottom: "1px solid #1a2a1a", background: j % 2 === 0 ? "#0f1a0f" : "#0d160d" }}>
                        <td style={{ padding: "7px 10px", color: "#c9a84c", fontFamily: "monospace" }}>{e.compte}</td>
                        <td style={{ padding: "7px 10px", color: "#c8c0a8" }}>{e.libelle}</td>
                        <td style={{ padding: "7px 10px", textAlign: "right", color: e.debit > 0 ? "#e8d4a0" : "#3a5a3a" }}>{e.debit > 0 ? fmtDH(e.debit) : "–"}</td>
                        <td style={{ padding: "7px 10px", textAlign: "right", color: e.credit > 0 ? "#e8d4a0" : "#3a5a3a" }}>{e.credit > 0 ? fmtDH(e.credit) : "–"}</td>
                      </tr>
                    ))}
                    <tr style={{ background: "#1a2e1a", fontWeight: "bold" }}>
                      <td colSpan={2} style={{ padding: "7px 10px", color: "#7ec880", fontSize: "0.88em" }}>TOTAUX</td>
                      <td style={{ padding: "7px 10px", textAlign: "right", color: "#c9a84c" }}>{fmtDH(s.ecritures.reduce((acc, e) => acc + (e.debit || 0), 0))}</td>
                      <td style={{ padding: "7px 10px", textAlign: "right", color: "#c9a84c" }}>{fmtDH(s.ecritures.reduce((acc, e) => acc + (e.credit || 0), 0))}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </>
          )}
          {s.references_pcm?.length > 0 && (
            <div style={{ marginTop: 8, display: "flex", flexWrap: "wrap", gap: 5 }}>
              {s.references_pcm.map((r, k) => <span key={k} style={{ background: "#0f1f0f", border: "1px solid #2a3d2a", borderRadius: 20, padding: "2px 9px", fontSize: "0.75em", color: "#7ec880" }}>📗 {r}</span>)}
            </div>
          )}
        </div>
      ))}

      {/* ── FISCALE ── */}
      {tab === "fiscale" && (data.analyse_fiscale?.sections || []).map((s, i) => (
        <div key={i} style={{ background: "#141208", border: "1px solid #2a2208", borderRadius: 10, padding: "14px 16px", marginBottom: 10 }}>
          <div style={{ color: "#c9a84c", fontWeight: "bold", marginBottom: 8 }}>▸ {s.sous_titre}</div>
          <div style={{ color: "#c8c0a8", lineHeight: 1.75, marginBottom: 10 }}>{s.contenu}</div>
          {s.calculs?.length > 0 && (
            <div style={{ background: "#0f1408", border: "1px solid #2a3a1a", borderRadius: 8, overflow: "hidden", marginBottom: 10 }}>
              <div style={{ fontSize: "0.7em", color: "#5a7a5a", padding: "5px 12px", background: "#1a2e1a", letterSpacing: "0.05em" }}>CALCULS FISCAUX</div>
              {s.calculs.map((c, j) => (
                <div key={j} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 14px", borderBottom: j < s.calculs.length - 1 ? "1px solid #1a2a1a" : "none", gap: 10 }}>
                  <span style={{ color: "#aaa090", flex: 1 }}>{c.libelle}</span>
                  <div style={{ display: "flex", gap: 8, alignItems: "center", flexShrink: 0 }}>
                    {c.montant != null && <span style={{ color: "#c8c0a8", fontFamily: "monospace", fontSize: "0.9em" }}>{fmtDH(c.montant)}</span>}
                    {c.taux != null && <span style={{ color: "#7ab8d4", background: "#0a1a2a", border: "1px solid #2a4a6a", borderRadius: 20, padding: "1px 9px", fontSize: "0.79em" }}>× {(c.taux * 100).toFixed(0)}%</span>}
                    {c.resultat != null && <span style={{ color: "#c9a84c", fontWeight: "bold", fontFamily: "monospace" }}>= {fmtDH(c.resultat)}</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
          {s.articles_cgi?.length > 0 && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
              {s.articles_cgi.map((a, k) => <span key={k} style={{ background: "#2a1a08", border: "1px solid #c9a84c44", borderRadius: 20, padding: "2px 10px", fontSize: "0.75em", color: "#c9a84c" }}>📌 {a}</span>)}
            </div>
          )}
        </div>
      ))}

      {/* ── SYNTHÈSE ── */}
      {tab === "synthese" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>

          {/* Points clés */}
          {data.synthese?.points_cles?.length > 0 && (
            <div style={{ background: "#0d1a0d", border: "1px solid #2a5a2a", borderRadius: 12, overflow: "hidden" }}>
              <div style={{ background: "#1a3a1a", padding: "10px 16px", display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: "1.1em" }}>✅</span>
                <span style={{ color: "#7ec880", fontWeight: "bold", fontSize: "0.9em" }}>Points Clés</span>
                <span style={{ background: "#2a5a2a", borderRadius: 20, padding: "1px 8px", fontSize: "0.72em", color: "#a8d8a8", marginLeft: "auto" }}>{data.synthese.points_cles.length}</span>
              </div>
              <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: 8 }}>
                {data.synthese.points_cles.map((item, i) => (
                  <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                    <div style={{ width: 20, height: 20, borderRadius: "50%", background: "#1a3a1a", border: "1px solid #2a5a2a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.7em", color: "#7ec880", flexShrink: 0, marginTop: 2 }}>{i + 1}</div>
                    <span style={{ color: "#c8c0a8", lineHeight: 1.65 }}>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Risques */}
          {data.synthese?.risques?.length > 0 && (
            <div style={{ background: "#1a1208", border: "1px solid #5a3a08", borderRadius: 12, overflow: "hidden" }}>
              <div style={{ background: "#2a1e08", padding: "10px 16px", display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: "1.1em" }}>⚠️</span>
                <span style={{ color: "#c9a84c", fontWeight: "bold", fontSize: "0.9em" }}>Risques Fiscaux</span>
                <span style={{ background: "#3a2a08", borderRadius: 20, padding: "1px 8px", fontSize: "0.72em", color: "#e8c880", marginLeft: "auto" }}>{data.synthese.risques.length}</span>
              </div>
              <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: 8 }}>
                {data.synthese.risques.map((item, i) => (
                  <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                    <span style={{ color: "#c9a84c", fontSize: "1em", flexShrink: 0, marginTop: 2 }}>▲</span>
                    <span style={{ color: "#c8c0a8", lineHeight: 1.65 }}>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recommandations */}
          {data.synthese?.recommandations?.length > 0 && (
            <div style={{ background: "#0a1018", border: "1px solid #2a4a7a", borderRadius: 12, overflow: "hidden" }}>
              <div style={{ background: "#0e1a28", padding: "10px 16px", display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: "1.1em" }}>💡</span>
                <span style={{ color: "#7ab8d4", fontWeight: "bold", fontSize: "0.9em" }}>Recommandations</span>
                <span style={{ background: "#1a3a5a", borderRadius: 20, padding: "1px 8px", fontSize: "0.72em", color: "#a8d8f8", marginLeft: "auto" }}>{data.synthese.recommandations.length}</span>
              </div>
              <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: 8 }}>
                {data.synthese.recommandations.map((item, i) => (
                  <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                    <span style={{ color: "#7ab8d4", flexShrink: 0, marginTop: 2 }}>→</span>
                    <span style={{ color: "#c8c0a8", lineHeight: 1.65 }}>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Avis expert */}
          {data.avis_expert && (
            <div style={{ background: "#0d1208", border: "1px solid #c9a84c55", borderLeft: "4px solid #c9a84c", borderRadius: 12, padding: "14px 18px" }}>
              <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 10 }}>
                <div style={{ width: 34, height: 34, background: "linear-gradient(135deg,#2a1a0a,#5a3a0a)", borderRadius: 10, border: "1px solid #c9a84c44", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.1em" }}>🎓</div>
                <div>
                  <div style={{ color: "#c9a84c", fontWeight: "bold", fontSize: "0.9em" }}>Avis de Maître Hassan</div>
                  <div style={{ color: "#5a7a5a", fontSize: "0.72em" }}>Expert-Comptable OECM · 25 ans d'expérience</div>
                </div>
              </div>
              <div style={{ color: "#c8c0a8", lineHeight: 1.8, fontStyle: "italic", borderTop: "1px solid #2a2208", paddingTop: 10 }}>"{data.avis_expert}"</div>
            </div>
          )}
        </div>
      )}

      {/* Action bar pour cas pratique */}
      <ActionBar
        onExport={onExport}
        plainText={`CAS PRATIQUE : ${data.titre}\n\n${data.resume}\n\nARTICLES : ${(data.articles_cites || []).join(", ")}\n\nSYNTHÈSE :\n${(data.synthese?.points_cles || []).map(x => "• " + x).join("\n")}\n\nRISQUES :\n${(data.synthese?.risques || []).map(x => "⚠ " + x).join("\n")}\n\nRECOMMANDATIONS :\n${(data.synthese?.recommandations || []).map(x => "→ " + x).join("\n")}\n\nAVIS EXPERT :\n${data.avis_expert || ""}`}
      />
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────

export default function App() {
  const [messages, setMessages]     = useState([]);
  const [input, setInput]           = useState("");
  const [casInput, setCasInput]     = useState("");
  const [loading, setLoading]       = useState(false);
  const [loadingMsg, setLoadingMsg] = useState("");
  const [mode, setMode]             = useState("chat");
  const [sessions, setSessions]     = useState([]);
  const [view, setView]             = useState("chat");
  const chatEnd = useRef(null);

  useEffect(() => { chatEnd.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);

  const sendChat = async (text) => {
    const q = (text || input).trim();
    if (!q || loading) return;
    setInput("");
    const userMsg = { role: "user", content: q };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);
    setLoadingMsg("🔍 Consultation CGI + recherche doctrine DGI…");
    try {
      const history = [...messages, userMsg]
        .filter((m) => m.role === "user" || m.role === "assistant")
        .map((m) => ({ role: m.role, content: m.content || "" }));
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 2000, system: SYSTEM_CHAT, messages: history, tools: [{ type: "web_search_20250305", name: "web_search" }] }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      const txt = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n") || "Réponse vide.";
      setMessages((prev) => [...prev, { role: "assistant", content: txt, question: q }]);
    } catch (err) {
      setMessages((prev) => [...prev, { role: "assistant", content: `⚠️ Erreur : ${err.message}` }]);
    }
    setLoading(false); setLoadingMsg("");
  };

  const sendCas = async (text) => {
    const q = (text || casInput).trim();
    if (!q || loading) return;
    setCasInput("");
    const userMsg = { role: "user", content: q };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);
    setLoadingMsg("📊 Analyse comptable & fiscale en cours…");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 2000, system: SYSTEM_CAS, messages: [{ role: "user", content: q }] }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      const raw = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("") || "";
      let casData = null, content = raw;
      try { casData = JSON.parse(raw.replace(/```json|```/g, "").trim()); content = "📋 " + casData.titre; } catch (_) {}
      setMessages((prev) => [...prev, { role: "assistant", isCas: !!casData, casData, content, question: q }]);
    } catch (err) {
      setMessages((prev) => [...prev, { role: "assistant", content: `⚠️ Erreur : ${err.message}` }]);
    }
    setLoading(false); setLoadingMsg("");
  };

  const saveSession = () => {
    if (!messages.length) return;
    setSessions((prev) => [{ id: Date.now(), title: messages.find((m) => m.role === "user")?.content?.slice(0, 60) || "Consultation", messages: [...messages], createdAt: Date.now() }, ...prev.slice(0, 19)]);
    setMessages([]);
  };

  // Export PDF de toute la session
  const exportSession = (msgs, title) => {
    const aiMsgs = msgs.filter(m => m.role === "assistant" && m.content);
    if (!aiMsgs.length) return;

    // Construire un HTML combiné de toute la session
    const pairRows = [];
    for (let i = 0; i < msgs.length; i++) {
      const m = msgs[i];
      if (m.role === "assistant") {
        const question = m.question || (i > 0 && msgs[i-1]?.role === "user" ? msgs[i-1].content : "");
        if (m.isCas && m.casData) {
          pairRows.push(buildCasHTML(question, m.casData));
        } else {
          pairRows.push(buildChatHTML(question, m.content || "", title));
        }
      }
    }

    const combined = pairRows.map(r =>
      r.replace(/<!DOCTYPE[^>]*>[\s\S]*?<body[^>]*>/i, "")
       .replace(/<\/body>[\s\S]*?<\/html>/i, "")
    ).join('<div style="border-top:3px dashed #c9a84c;margin:32px 0;padding-top:8px;font-size:.72em;color:#888;text-align:center">— Suite de la consultation —</div>');

    const fullHtml = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${title}</title>
    <style>
      body{font-family:Georgia,serif;max-width:820px;margin:32px auto;color:#111;padding:0 24px;font-size:14px}
      .header{border-bottom:3px solid #c9a84c;padding-bottom:12px;margin-bottom:24px}
      h1{color:#1a4a1a;margin:0 0 4px;font-size:1.4em}
      .question{background:#f0f7f0;border-left:4px solid #2d5a2d;padding:12px 16px;border-radius:0 8px 8px 0;margin-bottom:20px}
      .answer{background:#fdf8ee;border-left:4px solid #c9a84c;padding:14px 18px;border-radius:0 8px 8px 0}
      .label{font-size:.72em;font-weight:bold;text-transform:uppercase;margin-bottom:6px;color:#555}
      table{border-collapse:collapse;width:100%;margin:10px 0;font-size:.88em}
      th{background:#1a4a1a;color:#fff;padding:6px 10px}
      td{padding:6px 10px;border-bottom:1px solid #ddd}
      tr:nth-child(even) td{background:#f9f9f0}
      .badge{display:inline-block;background:#fdf0d0;border:1px solid #c9a84c;border-radius:20px;padding:2px 10px;font-size:.78em;color:#8a6a1a;margin:2px}
      .synthese-box{border-radius:8px;padding:12px 16px;margin-bottom:10px}
      .pts{background:#f0f7f0;border-left:3px solid #2d5a2d}
      .risques{background:#fffbf0;border-left:3px solid #c9a84c}
      .reco{background:#f0f4ff;border-left:3px solid #4a6aaa}
      .avis{background:#fdf8ee;border:1px solid #c9a84c;border-radius:8px;padding:14px 16px;font-style:italic;margin-top:14px}
      .footer{margin-top:32px;border-top:1px solid #ccc;padding-top:8px;font-size:.7em;color:#888;text-align:center}
      li{margin:4px 0} strong{color:#1a3a1a}
      @media print{.footer{position:fixed;bottom:0;width:100%}}
    </style></head><body>
    <div class="header">
      <h1>⚖️ Session de Consultation — Maître Hassan</h1>
      <p style="color:#666;font-size:.82em;margin:4px 0">${title} &nbsp;|&nbsp; ${new Date().toLocaleDateString("fr-FR", { dateStyle: "long" })} &nbsp;|&nbsp; ${aiMsgs.length} réponse(s)</p>
    </div>
    ${combined}
    <div class="footer">fiscalite-maroc.ma · Maître Hassan · CGI Maroc 2024 · IS · TVA · IR · PCM</div>
    </body></html>`;

    openPrint(fullHtml, title.replace(/\s+/g, "-").toLowerCase().slice(0, 40));
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0d1a0d", fontFamily: "'Georgia','Times New Roman',serif", color: "#e8dcc8", display: "flex", flexDirection: "column" }}>
      <div style={{ height: 3, background: "linear-gradient(90deg,#1a3a1a,#c9a84c,#2d5a2d,#c9a84c,#1a3a1a)" }} />

      {/* HEADER */}
      <header style={{ padding: "10px 18px", borderBottom: "1px solid #2a3d2a", background: "#0a150a", display: "flex", alignItems: "center", gap: 12, flexShrink: 0 }}>
        <div style={{ width: 38, height: 38, background: "linear-gradient(135deg,#1a3a1a,#2d5a2d)", borderRadius: 10, border: "1px solid #c9a84c44", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17 }}>⚖️</div>
        <div>
          <div style={{ fontWeight: "bold", color: "#c9a84c" }}>Maître Hassan · Expert Fiscal IA</div>
          <div style={{ fontSize: "0.62em", color: "#4a6a4a", letterSpacing: "0.05em" }}>CGI 2024 · DOCTRINE DGI · JURISPRUDENCE · EXPÉRIENCE TERRAIN</div>
        </div>
        <div style={{ marginLeft: "auto", display: "flex", gap: 6, flexWrap: "wrap" }}>
          {messages.length > 1 && <button onClick={saveSession} style={{ background: "#1a2e1a", border: "1px solid #2a5a2a", borderRadius: 8, padding: "4px 10px", color: "#7ec880", fontSize: "0.74em", cursor: "pointer", fontFamily: "inherit" }}>💾 Sauvegarder</button>}
          {messages.length > 0 && <button onClick={() => exportSession(messages, "Consultation CGI")} style={{ background: "none", border: "1px solid #c9a84c44", borderRadius: 8, padding: "4px 10px", color: "#c9a84c", fontSize: "0.74em", cursor: "pointer", fontFamily: "inherit" }}>📄 Export session</button>}
          <button onClick={() => setView(view === "chat" ? "history" : "chat")} style={{ background: view === "history" ? "#1a3a1a" : "none", border: `1px solid ${view === "history" ? "#2d5a2d" : "#1a2e1a"}`, borderRadius: 8, padding: "4px 10px", color: view === "history" ? "#c9a84c" : "#5a7a5a", fontSize: "0.74em", cursor: "pointer", fontFamily: "inherit" }}>
            📋 {sessions.length > 0 ? `Historique (${sessions.length})` : "Historique"}
          </button>
        </div>
      </header>

      {/* HISTORY */}
      {view === "history" && (
        <div style={{ flex: 1, overflowY: "auto", padding: "20px", maxWidth: 760, width: "100%", margin: "0 auto" }}>
          <h3 style={{ color: "#c9a84c", margin: "0 0 14px" }}>📋 Consultations sauvegardées</h3>
          {sessions.length === 0
            ? <div style={{ textAlign: "center", padding: 60, color: "#3a5a3a" }}><div style={{ fontSize: "2.5em", marginBottom: 10 }}>📋</div><div>Aucune consultation sauvegardée</div></div>
            : sessions.map((s) => (
              <div key={s.id} style={{ background: "#0f1f0f", border: "1px solid #2a3d2a", borderRadius: 12, marginBottom: 10, overflow: "hidden" }}>
                <div style={{ padding: "12px 16px", display: "flex", gap: 10, alignItems: "center", cursor: "pointer" }} onClick={() => { setMessages(s.messages); setView("chat"); }}>
                  <span>💬</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: "#c8c0a8", fontWeight: "bold", fontSize: "0.85em" }}>{s.title}</div>
                    <div style={{ color: "#4a6a4a", fontSize: "0.72em", marginTop: 2 }}>{new Date(s.createdAt).toLocaleDateString("fr-FR")} · {s.messages.filter((m) => m.role === "user").length} question(s)</div>
                  </div>
                  <span style={{ color: "#3a5a3a" }}>›</span>
                </div>
                <div style={{ borderTop: "1px solid #1a2e1a", padding: "6px 14px", display: "flex", gap: 6, justifyContent: "flex-end" }}>
                  <button onClick={() => { setMessages(s.messages); setView("chat"); }} style={{ background: "none", border: "1px solid #2a5a2a44", borderRadius: 6, padding: "2px 10px", color: "#5a7a5a", cursor: "pointer", fontSize: "0.74em", fontFamily: "inherit" }}>▶ Reprendre</button>
                  <button onClick={() => exportSession(s.messages, s.title)} style={{ background: "none", border: "1px solid #c9a84c44", borderRadius: 6, padding: "2px 10px", color: "#c9a84c", cursor: "pointer", fontSize: "0.74em", fontFamily: "inherit" }}>📄 PDF</button>
                  <button onClick={() => setSessions((prev) => prev.filter((x) => x.id !== s.id))} style={{ background: "none", border: "1px solid #7a4a4a44", borderRadius: 6, padding: "2px 10px", color: "#7a4a4a", cursor: "pointer", fontSize: "0.74em", fontFamily: "inherit" }}>🗑</button>
                </div>
              </div>
            ))
          }
        </div>
      )}

      {/* CHAT */}
      {view === "chat" && (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", maxWidth: 860, width: "100%", margin: "0 auto", padding: "0 14px", minHeight: 0, overflow: "hidden" }}>
          <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 14, paddingTop: 16, paddingBottom: 10 }}>

            {/* Welcome */}
            {messages.length === 0 && (
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flex: 1, gap: 18, paddingTop: 10 }}>
                <div style={{ textAlign: "center", maxWidth: 500 }}>
                  <div style={{ fontSize: "2.5em", marginBottom: 8 }}>⚖️</div>
                  <h2 style={{ color: "#c9a84c", margin: "0 0 6px", fontSize: "1.2em" }}>Maître Hassan — Expert Fiscal IA</h2>
                  <p style={{ color: "#5a7a5a", margin: 0, fontSize: "0.85em", lineHeight: 1.65 }}>
                    25 ans d'expérience · CGI 2024 · Doctrine DGI · Jurisprudence<br />
                    Posez votre question ou soumettez un cas pratique.
                  </p>
                </div>
                <div style={{ display: "flex", gap: 12, flexWrap: "wrap", justifyContent: "center", maxWidth: 560 }}>
                  {[{ id: "chat", icon: "💬", title: "Question libre", desc: "IS, TVA, IR, retenues, délais…" }, { id: "cas", icon: "📋", title: "Cas pratique", desc: "Analyse comptable + écritures PCM" }].map((m) => (
                    <div key={m.id} onClick={() => setMode(m.id)} style={{ background: mode === m.id ? "linear-gradient(135deg,#1a3a1a,#2d5a2d)" : "#0f1f0f", border: `2px solid ${mode === m.id ? "#4a7a2a" : "#2a3d2a"}`, borderRadius: 14, padding: "14px 18px", cursor: "pointer", flex: 1, minWidth: 180, textAlign: "center", transition: "all .2s" }}>
                      <div style={{ fontSize: "1.6em", marginBottom: 5 }}>{m.icon}</div>
                      <div style={{ color: "#c9a84c", fontWeight: "bold", marginBottom: 3, fontSize: "0.9em" }}>{m.title}</div>
                      <div style={{ color: "#5a7a5a", fontSize: "0.77em" }}>{m.desc}</div>
                    </div>
                  ))}
                </div>
                <div style={{ width: "100%", maxWidth: 680 }}>
                  <div style={{ fontSize: "0.7em", color: "#3a5a3a", marginBottom: 7, letterSpacing: "0.05em" }}>{mode === "cas" ? "EXEMPLES DE CAS PRATIQUES" : "QUESTIONS FRÉQUENTES"}</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
                    {(mode === "cas" ? SUGGESTIONS_CAS : SUGGESTIONS_CHAT).map((q, i) => (
                      <button key={i} onClick={() => mode === "cas" ? sendCas(q) : sendChat(q)}
                        style={{ background: "#0f1f0f", border: "1px solid #2a3d2a", borderRadius: 20, padding: "6px 13px", color: "#7a9a7a", fontSize: "0.77em", cursor: "pointer", fontFamily: "inherit", textAlign: "left", lineHeight: 1.4 }}
                        onMouseEnter={(e) => { e.currentTarget.style.borderColor = "#c9a84c"; e.currentTarget.style.color = "#c9a84c"; }}
                        onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#2a3d2a"; e.currentTarget.style.color = "#7a9a7a"; }}
                      >{q}</button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Messages */}
            {messages.map((msg, i) => {
              const isUser = msg.role === "user";
              return (
                <div key={i} style={{ display: "flex", flexDirection: isUser ? "row-reverse" : "row", gap: 10, alignItems: "flex-start" }}>
                  <div style={{ width: 30, height: 30, borderRadius: 8, flexShrink: 0, background: isUser ? "linear-gradient(135deg,#2d4a1a,#4a7a2a)" : "linear-gradient(135deg,#2a1a0a,#5a3a0a)", border: `1px solid ${isUser ? "#4a7a2a55" : "#c9a84c44"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.8em" }}>
                    {isUser ? "👤" : msg.isCas ? "📋" : "⚖️"}
                  </div>
                  <div style={{ maxWidth: "85%", background: isUser ? "#162616" : "#1a1408", border: `1px solid ${isUser ? "#2d5a2d" : "#3a2a0a"}`, borderRadius: isUser ? "12px 4px 12px 12px" : "4px 12px 12px 12px", padding: "11px 14px" }}>
                    {msg.isCas && msg.casData
                      ? <CasView data={msg.casData} question={msg.question} onExport={() => openPrint(buildCasHTML(msg.question || "", msg.casData))} />
                      : <>
                          <MD text={msg.content} />
                          {!isUser && msg.content && !msg.content.startsWith("⚠️") && (
                            <ActionBar
                              onExport={() => openPrint(buildChatHTML(msg.question || "", msg.content, "Consultation CGI"))}
                              plainText={`QUESTION :\n${msg.question || ""}\n\nRÉPONSE DE MAÎTRE HASSAN :\n${msg.content}`}
                            />
                          )}
                        </>
                    }
                  </div>
                </div>
              );
            })}

            {/* Loading */}
            {loading && (
              <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                <div style={{ width: 30, height: 30, borderRadius: 8, background: "linear-gradient(135deg,#2a1a0a,#5a3a0a)", border: "1px solid #c9a84c44", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.8em" }}>⚖️</div>
                <div style={{ background: "#1a1408", border: "1px solid #3a2a0a", borderRadius: "4px 12px 12px 12px", padding: "12px 16px" }}>
                  <div style={{ display: "flex", gap: 5, alignItems: "center", marginBottom: 7 }}>
                    {[0, 1, 2].map((n) => <div key={n} style={{ width: 7, height: 7, borderRadius: "50%", background: "#c9a84c", animation: `pulse 1.2s ease-in-out ${n * 0.2}s infinite` }} />)}
                    <span style={{ marginLeft: 8, fontSize: "0.77em", color: "#5a7a5a" }}>{loadingMsg || "Analyse en cours…"}</span>
                  </div>
                  <div style={{ display: "flex", gap: 10, fontSize: "0.7em", color: "#3a5a3a" }}>
                    <span>📖 CGI 2024</span><span>🌐 Doctrine DGI</span><span>💼 Jurisprudence</span><span>🧮 Calculs</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={chatEnd} />
          </div>

          {/* INPUT */}
          <div style={{ flexShrink: 0, paddingBottom: 12 }}>
            <div style={{ display: "flex", gap: 0, marginBottom: 8, background: "#0a150a", borderRadius: 10, padding: 3, width: "fit-content", border: "1px solid #1a2e1a" }}>
              {[{ id: "chat", icon: "💬", label: "Question libre" }, { id: "cas", icon: "📋", label: "Cas pratique" }].map((m) => (
                <button key={m.id} onClick={() => setMode(m.id)} style={{ background: mode === m.id ? "linear-gradient(135deg,#1a3a1a,#2d5a2d)" : "none", border: "none", borderRadius: 8, padding: "5px 14px", color: mode === m.id ? "#c9a84c" : "#4a6a4a", cursor: "pointer", fontSize: "0.78em", fontFamily: "inherit", display: "flex", alignItems: "center", gap: 4 }}>
                  {m.icon} {m.label}
                </button>
              ))}
            </div>

            {mode === "chat"
              ? <div style={{ background: "#0f1f0f", border: "1px solid #2a3d2a", borderRadius: 14, padding: "4px 4px 4px 14px", display: "flex", alignItems: "flex-end", gap: 8 }}>
                  <textarea value={input} onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendChat(); } }}
                    placeholder="Posez votre question fiscale… (Entrée pour envoyer)"
                    rows={1} style={{ flex: 1, background: "none", border: "none", outline: "none", color: "#e8dcc8", fontSize: "0.87em", resize: "none", fontFamily: "inherit", lineHeight: 1.55, padding: "10px 0", maxHeight: 130, overflowY: "auto" }}
                    onInput={(e) => { e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 130) + "px"; }} />
                  <button onClick={() => sendChat()} disabled={!input.trim() || loading} style={{ width: 40, height: 40, borderRadius: 10, border: "none", background: input.trim() && !loading ? "linear-gradient(135deg,#2d5a2d,#4a7a2a)" : "#1a2e1a", color: input.trim() && !loading ? "#c9a84c" : "#3a5a3a", cursor: input.trim() && !loading ? "pointer" : "not-allowed", fontSize: "1em", flexShrink: 0 }}>➤</button>
                </div>
              : <div style={{ background: "#0a0814", border: "1px solid #3a1a5a", borderRadius: 14, padding: "4px 4px 4px 14px", display: "flex", alignItems: "flex-end", gap: 8 }}>
                  <textarea value={casInput} onChange={(e) => setCasInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendCas(); } }}
                    placeholder="Décrivez votre cas pratique avec les montants… (Entrée pour envoyer)"
                    rows={3} style={{ flex: 1, background: "none", border: "none", outline: "none", color: "#e0d4f8", fontSize: "0.87em", resize: "none", fontFamily: "inherit", lineHeight: 1.55, padding: "10px 0", maxHeight: 140, overflowY: "auto" }}
                    onInput={(e) => { e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 140) + "px"; }} />
                  <button onClick={() => sendCas()} disabled={!casInput.trim() || loading} style={{ width: 40, height: 40, borderRadius: 10, border: "none", background: casInput.trim() && !loading ? "linear-gradient(135deg,#3a1a5a,#6a2aaa)" : "#1a0a2a", color: casInput.trim() && !loading ? "#c9a0f8" : "#4a2a6a", cursor: casInput.trim() && !loading ? "pointer" : "not-allowed", fontSize: "1em", flexShrink: 0 }}>➤</button>
                </div>
            }
          </div>
        </div>
      )}

      <div style={{ textAlign: "center", padding: "6px 0 10px", fontSize: "0.65em", color: "#2a4a2a", borderTop: "1px solid #1a2e1a", flexShrink: 0 }}>
        Maître Hassan · CGI Maroc 2024 · IS · TVA · IR · Plan Comptable Marocain
      </div>

      <style>{`
        @keyframes pulse { 0%,100%{opacity:.3;transform:scale(.8)} 50%{opacity:1;transform:scale(1)} }
        ::-webkit-scrollbar{width:4px} ::-webkit-scrollbar-track{background:#0d1a0d} ::-webkit-scrollbar-thumb{background:#2a3d2a;border-radius:3px}
        textarea::placeholder{color:#3a5a3a}
      `}</style>
    </div>
  );
}
